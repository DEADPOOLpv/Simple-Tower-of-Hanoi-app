package com.example.tower_of_hanoi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
